Great Egret — sixth My Bird Journal icon

Includes 1024px opaque sRGB artwork, native Icon Composer package, Liquid Glass preview, and imagegen prompt. Uses the same approved inner-edge specular treatment as the original.

Drag MyBirdJournal-GreatEgret.icon into the Xcode Project navigator and include it in your app target. Set Target > General > App Icons and Launch Screen > App Icon to MyBirdJournal-GreatEgret (without the extension).

Validated with Xcode 27 actool for iPhone and iPad.
